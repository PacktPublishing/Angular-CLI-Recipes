import { RatingPipe } from './rating.pipe';

describe('RatingPipe', () => {
  it('create an instance', () => {
    const pipe = new RatingPipe();
    expect(pipe).toBeTruthy();
  });
});
